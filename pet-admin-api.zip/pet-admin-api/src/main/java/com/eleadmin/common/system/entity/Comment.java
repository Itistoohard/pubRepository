package com.eleadmin.common.system.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 评论
 */
@Data
@ApiModel(description = "评论")
@TableName("comment")
public class Comment implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("id")
    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("hospitalId")
    private Integer hospitalId;

    @ApiModelProperty("userId")
    private Integer userId;

    @ApiModelProperty("医院名称")
    private String hospitalTitle;

    @ApiModelProperty("创建时间")
    private String createTime;

    @ApiModelProperty("创建人")
    private String createUser;

    @ApiModelProperty("评论")
    private String comment;

    @ApiModelProperty("回复")
    private String reply;

    @ApiModelProperty("回复人")
    private String replyUser;

    @ApiModelProperty("回复时间")
    private String replyTime;

    @TableField(exist = false)
    private String avatar;

    @TableField(exist = false)
    private String cname;

    @TableField(exist = false)
    private String cavatar;

    @TableField(exist = false)
    private String vname;
}
