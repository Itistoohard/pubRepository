package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eleadmin.common.system.entity.Dictionary;

/**
 * 字典Mapper
 */
public interface DictionaryMapper extends BaseMapper<Dictionary> {

}
