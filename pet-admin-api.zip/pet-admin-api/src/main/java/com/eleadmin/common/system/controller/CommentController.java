package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Hospital;
import com.eleadmin.common.system.entity.Comment;
import com.eleadmin.common.system.entity.User;
import com.eleadmin.common.system.param.CommentParam;
import com.eleadmin.common.system.service.CommentService;
import com.eleadmin.common.system.service.HospitalService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 评论控制器
 */
@Api(tags = "评论管理")
@RestController
@RequestMapping("/system/comment")
public class CommentController extends BaseController {
    @Resource
    private CommentService commentService;
    @Resource
    private HospitalService hospitalService;


    @OperationLog
    @ApiOperation("分页查询")
    @GetMapping("/page")
    public ApiResult<PageResult<Comment>> page(CommentParam param) {
        return success(commentService.pageRel(param));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping()
    public ApiResult<List<Comment>> list(CommentParam param) {
        return success(commentService.listRel(param));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/{id}")
    public ApiResult<Comment> get(@PathVariable("id") Integer id) {
        return success(commentService.getById(id));
    }

    @OperationLog
    @ApiOperation("添加")
    @PostMapping()
    public ApiResult<?> save(@RequestBody Comment comment) {
        User user = getLoginUser();
        Hospital hospital = hospitalService.getById(comment.getHospitalId());
        comment.setHospitalTitle(hospital.getTitle());
        comment.setCreateUser(user.getUsername());
        comment.setCreateTime(DateUtil.now());
        if (commentService.save(comment)) {
            return success("添加成功");
        }
        return fail("添加失败");
    }

    @OperationLog
    @ApiOperation("修改")
    @PutMapping()
    public ApiResult<?> update(@RequestBody Comment comment) {
        User user = getLoginUser();
        Comment comment1 = commentService.getById(comment.getId());
        comment1.setReplyTime(DateUtil.now());
        comment1.setReplyUser(user.getUsername());
        comment1.setReply(comment.getReply());
        if (commentService.updateById(comment1)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }

    @OperationLog
    @ApiOperation("删除")
    @DeleteMapping("/{id}")
    public ApiResult<?> remove(@PathVariable("id") Integer id) {
        if (commentService.removeById(id)) {
            return success("删除成功");
        }
        return fail("删除失败");
    }


}
