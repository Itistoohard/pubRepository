package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.ActivityClassify;

/**
 * 活动Service
 */
public interface ActivityClassifyService extends IService<ActivityClassify> {

}
