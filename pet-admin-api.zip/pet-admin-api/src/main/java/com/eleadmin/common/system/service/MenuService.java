package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.Menu;

/**
 * 菜单Service
 */
public interface MenuService extends IService<Menu> {

}
