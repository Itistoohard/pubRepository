package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.system.entity.HospitalApply;
import com.eleadmin.common.system.mapper.HospitalApplyMapper;
import com.eleadmin.common.system.service.HospitalApplyService;
import org.springframework.stereotype.Service;

/**
 * 医院服务实现类
 */
@Service
public class HospitalApplyServiceImpl extends ServiceImpl<HospitalApplyMapper, HospitalApply> implements HospitalApplyService {

}
