package com.eleadmin.common.system.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 宠物
 */
@Data
@ApiModel(description = "宠物")
@TableName("pet")
public class Pet implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("id")
    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("宠物名称")
    private String title;

    @ApiModelProperty("宠物内容")
    private String details;

    @ApiModelProperty("宠物图片")
    private String image;

    @ApiModelProperty("宠物性别")
    private String xingbie;

    @ApiModelProperty("宠物年龄")
    private String nianling;

    @ApiModelProperty("联系电话")
    private String phone;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("创建时间")
    private String createTime;

    @ApiModelProperty("创建人")
    private String createUser;
}
