package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eleadmin.common.system.entity.PetApply;

/**
 * 宠物Mapper
 */
public interface PetApplyMapper extends BaseMapper<PetApply> {

}
