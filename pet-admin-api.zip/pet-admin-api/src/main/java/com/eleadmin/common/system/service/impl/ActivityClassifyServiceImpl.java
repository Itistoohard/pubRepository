package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.system.entity.ActivityClassify;
import com.eleadmin.common.system.mapper.ActivityClassifyMapper;
import com.eleadmin.common.system.service.ActivityClassifyService;
import org.springframework.stereotype.Service;

/**
 * 活动服务实现类
 */
@Service
public class ActivityClassifyServiceImpl extends ServiceImpl<ActivityClassifyMapper, ActivityClassify> implements ActivityClassifyService {

}
