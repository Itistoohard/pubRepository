package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.system.entity.ActivityApply;
import com.eleadmin.common.system.mapper.ActivityApplyMapper;
import com.eleadmin.common.system.service.ActivityApplyService;
import org.springframework.stereotype.Service;

/**
 * 活动服务实现类
 */
@Service
public class ActivityApplyServiceImpl extends ServiceImpl<ActivityApplyMapper, ActivityApply> implements ActivityApplyService {

}
