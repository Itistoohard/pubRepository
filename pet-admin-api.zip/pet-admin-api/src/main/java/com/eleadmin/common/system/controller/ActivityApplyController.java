package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Activity;
import com.eleadmin.common.system.entity.ActivityApply;
import com.eleadmin.common.system.entity.User;
import com.eleadmin.common.system.param.ActivityApplyParam;
import com.eleadmin.common.system.service.ActivityApplyService;
import com.eleadmin.common.system.service.ActivityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;

/**
 * 活动控制器
 */
@Api(tags = "活动管理")
@RestController
@RequestMapping("/system/activityApply")
public class ActivityApplyController extends BaseController {
    @Resource
    private ActivityApplyService activityApplyService;
    @Resource
    private ActivityService activityService;


    @OperationLog
    @ApiOperation("分页查询")
    @GetMapping("/page")
    public ApiResult<PageResult<ActivityApply>> page(ActivityApplyParam param) {
        PageParam<ActivityApply, ActivityApplyParam> page = new PageParam<>(param);
        return success(activityApplyService.page(page, page.getWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping()
    public ApiResult<List<ActivityApply>> list(ActivityApplyParam param) {
        PageParam<ActivityApply, ActivityApplyParam> page = new PageParam<>(param);
        return success(activityApplyService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/{id}")
    public ApiResult<ActivityApply> get(@PathVariable("id") Integer id) {
        return success(activityApplyService.getById(id));
    }

    @OperationLog
    @ApiOperation("添加")
    @PostMapping()
    public ApiResult<?> save(@RequestBody ActivityApply activityApply) {
        User user = getLoginUser();
        Activity activity = activityService.getById(activityApply.getActivityId());
        activityApply.setCreateUser(user.getUsername());
        activityApply.setCreateTime(DateUtil.now());
        activityApply.setActivityTitle(activity.getTitle());
        if (activityApplyService.save(activityApply)) {
            return success("添加成功");
        }
        return fail("添加失败");
    }

    @OperationLog
    @ApiOperation("修改")
    @PutMapping()
    public ApiResult<?> update(@RequestBody ActivityApply activityApply) {
        Activity activity = activityService.getById(activityApply.getActivityId());
        activityApply.setActivityTitle(activity.getTitle());
        if (activityApplyService.updateById(activityApply)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }

    @OperationLog
    @ApiOperation("删除")
    @DeleteMapping("/{id}")
    public ApiResult<?> remove(@PathVariable("id") Integer id) {
        if (activityApplyService.removeById(id)) {
            return success("删除成功");
        }
        return fail("删除失败");
    }


}
