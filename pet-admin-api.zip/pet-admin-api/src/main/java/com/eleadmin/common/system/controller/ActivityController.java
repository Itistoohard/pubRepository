package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Activity;
import com.eleadmin.common.system.entity.User;
import com.eleadmin.common.system.param.ActivityParam;
import com.eleadmin.common.system.service.ActivityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 活动控制器
 */
@Api(tags = "活动管理")
@RestController
@RequestMapping("/system/activity")
public class ActivityController extends BaseController {
    @Resource
    private ActivityService activityService;


    @OperationLog
    @ApiOperation("分页查询")
    @GetMapping("/page")
    public ApiResult<PageResult<Activity>> page(ActivityParam param) {
        PageParam<Activity, ActivityParam> page = new PageParam<>(param);
        return success(activityService.page(page, page.getWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping()
    public ApiResult<List<Activity>> list(ActivityParam param) {
        PageParam<Activity, ActivityParam> page = new PageParam<>(param);
        return success(activityService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/{id}")
    public ApiResult<Activity> get(@PathVariable("id") Integer id) {
        return success(activityService.getById(id));
    }

    @OperationLog
    @ApiOperation("添加")
    @PostMapping()
    public ApiResult<?> save(@RequestBody Activity activity) {
        User user = getLoginUser();
        activity.setCreateUser(user.getUsername());
        activity.setCreateTime(DateUtil.now());
        if (activityService.save(activity)) {
            return success("添加成功");
        }
        return fail("添加失败");
    }

    @OperationLog
    @ApiOperation("修改")
    @PutMapping()
    public ApiResult<?> update(@RequestBody Activity activity) {
        if (activityService.updateById(activity)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }

    @OperationLog
    @ApiOperation("删除")
    @DeleteMapping("/{id}")
    public ApiResult<?> remove(@PathVariable("id") Integer id) {
        if (activityService.removeById(id)) {
            return success("删除成功");
        }
        return fail("删除失败");
    }


}
