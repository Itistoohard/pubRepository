package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Comment;
import com.eleadmin.common.system.param.CommentParam;

import java.util.List;

/**
 * 评论Service
 */
public interface CommentService extends IService<Comment> {

    /**
     * 关联分页查询
     *
     * @param param 查询参数
     * @return PageResult<Comment>
     */
    PageResult<Comment> pageRel(CommentParam param);

    /**
     * 关联查询全部
     *
     * @param param 查询参数
     * @return List<Comment>
     */
    List<Comment> listRel(CommentParam param);

}
