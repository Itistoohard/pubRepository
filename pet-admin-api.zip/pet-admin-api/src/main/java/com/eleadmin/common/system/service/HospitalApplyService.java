package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.HospitalApply;

/**
 * 医院Service
 */
public interface HospitalApplyService extends IService<HospitalApply> {

}
