package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eleadmin.common.system.entity.Activity;

/**
 * 活动Mapper
 */
public interface ActivityMapper extends BaseMapper<Activity> {

}
