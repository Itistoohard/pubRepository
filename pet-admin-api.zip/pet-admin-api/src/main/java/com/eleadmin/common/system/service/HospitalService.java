package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.Hospital;

/**
 * 医院Service
 */
public interface HospitalService extends IService<Hospital> {

}
