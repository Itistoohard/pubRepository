package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eleadmin.common.system.entity.Role;

/**
 * 角色Mapper
 */
public interface RoleMapper extends BaseMapper<Role> {

}
