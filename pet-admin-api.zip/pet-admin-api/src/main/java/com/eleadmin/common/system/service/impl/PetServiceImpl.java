package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.system.entity.Pet;
import com.eleadmin.common.system.mapper.PetMapper;
import com.eleadmin.common.system.service.PetService;
import org.springframework.stereotype.Service;

/**
 * 宠物服务实现类
 */
@Service
public class PetServiceImpl extends ServiceImpl<PetMapper, Pet> implements PetService {

}
