package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eleadmin.common.system.entity.HospitalApply;

/**
 * 医院Mapper
 */
public interface HospitalApplyMapper extends BaseMapper<HospitalApply> {

}
