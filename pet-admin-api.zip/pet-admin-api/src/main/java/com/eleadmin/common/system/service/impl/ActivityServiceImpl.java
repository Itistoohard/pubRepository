package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.system.entity.Activity;
import com.eleadmin.common.system.mapper.ActivityMapper;
import com.eleadmin.common.system.service.ActivityService;
import org.springframework.stereotype.Service;

/**
 * 活动服务实现类
 */
@Service
public class ActivityServiceImpl extends ServiceImpl<ActivityMapper, Activity> implements ActivityService {

}
