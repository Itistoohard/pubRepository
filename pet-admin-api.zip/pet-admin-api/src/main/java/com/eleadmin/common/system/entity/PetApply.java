package com.eleadmin.common.system.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 宠物领养寄养
 */
@Data
@ApiModel(description = "宠物领养寄养")
@TableName("pet_apply")
public class PetApply implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("id")
    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("petId")
    private Integer petId;

    @ApiModelProperty("userId")
    private Integer userId;

    @ApiModelProperty("宠物名称")
    private String petTitle;

    @ApiModelProperty("分类")
    private String type;

    @ApiModelProperty("创建时间")
    private String createTime;

    @ApiModelProperty("创建人")
    private String createUser;
}
