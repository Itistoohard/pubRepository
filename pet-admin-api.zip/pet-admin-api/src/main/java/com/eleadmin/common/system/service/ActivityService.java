package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.Activity;

/**
 * 活动Service
 */
public interface ActivityService extends IService<Activity> {

}
