package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.system.entity.PetApply;
import com.eleadmin.common.system.mapper.PetApplyMapper;
import com.eleadmin.common.system.service.PetApplyService;
import org.springframework.stereotype.Service;

/**
 * 宠物服务实现类
 */
@Service
public class PetApplyServiceImpl extends ServiceImpl<PetApplyMapper, PetApply> implements PetApplyService {

}
