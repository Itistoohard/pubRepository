package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eleadmin.common.system.entity.ActivityApply;

/**
 * 活动Mapper
 */
public interface ActivityApplyMapper extends BaseMapper<ActivityApply> {

}
