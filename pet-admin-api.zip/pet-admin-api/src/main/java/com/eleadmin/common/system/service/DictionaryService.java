package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.Dictionary;

/**
 * 字典Service
 */
public interface DictionaryService extends IService<Dictionary> {

}
