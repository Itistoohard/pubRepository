package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.system.entity.*;
import com.eleadmin.common.system.param.*;
import com.eleadmin.common.system.service.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description:TODO
 * @author: 96034
 * @create: 2024/2/21
 */
@Api(tags = "小程序")
@RestController
@RequestMapping("/wx")
public class WeiXinController extends BaseController {
    @Resource
    private ActivityService activityService;
    @Resource
    private HospitalService hospitalService;
    @Resource
    private PetService petService;
    @Resource
    private UserService userService;
    @Resource
    private ActivityApplyService activityApplyService;
    @Resource
    private PetApplyService petApplyService;
    @Resource
    private HospitalApplyService hospitalApplyService;
    @Resource
    private CommentService commentService;

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/activity/list")
    public ApiResult<List<Activity>> list(ActivityParam param) {
        PageParam<Activity, ActivityParam> page = new PageParam<>(param);
        return success(activityService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/activityApply/list")
    public ApiResult<List<ActivityApply>> list(ActivityApplyParam param) {
        PageParam<ActivityApply, ActivityApplyParam> page = new PageParam<>(param);
        return success(activityApplyService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/activity/id")
    public ApiResult<Activity> get(ActivityParam param) {
        return success(activityService.getById(param.getId()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/hospital/list")
    public ApiResult<List<Hospital>> list(HospitalParam param) {
        PageParam<Hospital, HospitalParam> page = new PageParam<>(param);
        return success(hospitalService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/hospitalApply/list")
    public ApiResult<List<HospitalApply>> list(HospitalApplyParam param) {
        PageParam<HospitalApply, HospitalApplyParam> page = new PageParam<>(param);
        return success(hospitalApplyService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/hospital/id")
    public ApiResult<Hospital> get(HospitalParam param) {
        return success(hospitalService.getById(param.getId()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/pet/list")
    public ApiResult<List<Pet>> list(PetParam param) {
        PageParam<Pet, PetParam> page = new PageParam<>(param);
        return success(petService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/petLy/list")
    public ApiResult<List<PetApply>> petLy(PetApplyParam param) {
        param.setType("领养");
        PageParam<PetApply, PetApplyParam> page = new PageParam<>(param);
        return success(petApplyService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/petJy/list")
    public ApiResult<List<PetApply>> petJy(PetApplyParam param) {
        param.setType("寄养");
        PageParam<PetApply, PetApplyParam> page = new PageParam<>(param);
        return success(petApplyService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/pet/id")
    public ApiResult<Pet> get(PetParam param) {
        return success(petService.getById(param.getId()));
    }

    @OperationLog
    @ApiOperation("活动申请添加")
    @PostMapping("/activityApply/add")
    public ApiResult<?> activityApplySave(@RequestBody ActivityApply activityApply) {
        ActivityApply apply = activityApplyService.getOne(new QueryWrapper<ActivityApply>().eq("user_id",activityApply.getUserId()).eq("activity_id",activityApply.getActivityId()));
        if(ObjectUtil.isNotEmpty(apply)){
            return fail("你已经申请过");
        }
        User user = userService.getById(activityApply.getUserId());
        activityApply.setCreateUser(user.getUsername());
        activityApply.setCreateTime(DateUtil.now());
        if (activityApplyService.save(activityApply)) {
            return success("申请成功");
        }
        return fail("申请失败");
    }

    @OperationLog
    @ApiOperation("宠物领养添加")
    @PostMapping("/petApply/add")
    public ApiResult<?> petApplySave(@RequestBody PetApply petApply) {
        PetApply apply = petApplyService.getOne(new QueryWrapper<PetApply>().eq("user_id",petApply.getUserId()).eq("pet_id",petApply.getPetId()));
        if(ObjectUtil.isNotEmpty(apply)){
            return fail("你已经领养过");
        }
        Pet pet = petService.getById(petApply.getPetId());
        if(!pet.getStatus().equals("0")){
            return fail("已经被领养");
        }
        User user = userService.getById(petApply.getUserId());
        Pet pet1 = petService.getOne(new QueryWrapper<Pet>().eq("create_user",user.getUsername()));
        if(ObjectUtil.isNotEmpty(pet1)){
            return fail("这是您的寄养，无法被自己领养");
        }
        petApply.setCreateUser(user.getUsername());
        petApply.setCreateTime(DateUtil.now());
        if (petApplyService.save(petApply)) {
            Pet pet2 = petService.getById(petApply.getPetId());
            pet2.setStatus("1");
            petService.updateById(pet2);
            return success("领养成功");
        }
        return fail("领养失败");
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping("/comment/list")
    public ApiResult<List<Comment>> list(CommentParam param) {
        return success(commentService.listRel(param));
    }

    @OperationLog
    @ApiOperation("添加评论")
    @PostMapping("/comment/add")
    public ApiResult<?> commentSave(@RequestBody Comment comment) {
        User user = userService.getById(comment.getUserId());
        comment.setCreateUser(user.getUsername());
        comment.setCreateTime(DateUtil.now());
        if (commentService.save(comment)) {
            return success("评论成功");
        }
        return fail("评论失败");
    }

    @OperationLog
    @ApiOperation("宠物寄养添加")
    @PostMapping("/pet/add")
    public ApiResult<?> petSave(@RequestBody Pet pet) {
        User user = userService.getByUsername(pet.getCreateUser());
        pet.setCreateTime(DateUtil.now());
        if (petService.save(pet)) {
            PetApply petApply = new PetApply();
            petApply.setPetTitle(pet.getTitle());
            petApply.setCreateTime(DateUtil.now());
            petApply.setCreateUser(user.getUsername());
            petApply.setPetId(pet.getId());
            petApply.setType("寄养");
            petApply.setUserId(user.getUserId());
            petApplyService.save(petApply);
            return success("寄养成功");
        }
        return fail("寄养失败");
    }

    @OperationLog
    @ApiOperation("医院预约添加")
    @PostMapping("/hospitalApply/add")
    public ApiResult<?> hospitalApply(@RequestBody HospitalApply hospitalApply) {
        HospitalApply apply = hospitalApplyService.getOne(new QueryWrapper<HospitalApply>().eq("user_id",hospitalApply.getUserId()).eq("hospital_id",hospitalApply.getHospitalId()));
        if(ObjectUtil.isNotEmpty(apply)){
            return fail("你已经预约过");
        }
        User user = userService.getById(hospitalApply.getUserId());
        hospitalApply.setCreateUser(user.getUsername());
        hospitalApply.setCreateTime(DateUtil.now());
        if (hospitalApplyService.save(hospitalApply)) {
            return success("预约成功");
        }
        return fail("预约失败");
    }

    @OperationLog
    @ApiOperation("修改用户")
    @PostMapping("/user/update")
    public ApiResult<?> userUpdate(@RequestBody User user) {
        if (userService.updateUser(user)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }
}
