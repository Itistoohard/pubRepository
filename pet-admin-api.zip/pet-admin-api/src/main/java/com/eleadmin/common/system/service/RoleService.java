package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.Role;

/**
 * 角色Service
 */
public interface RoleService extends IService<Role> {

}
