package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Hospital;
import com.eleadmin.common.system.entity.User;
import com.eleadmin.common.system.param.HospitalParam;
import com.eleadmin.common.system.service.HospitalService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 医院控制器
 */
@Api(tags = "医院管理")
@RestController
@RequestMapping("/system/hospital")
public class HospitalController extends BaseController {
    @Resource
    private HospitalService hospitalService;


    @OperationLog
    @ApiOperation("分页查询")
    @GetMapping("/page")
    public ApiResult<PageResult<Hospital>> page(HospitalParam param) {
        PageParam<Hospital, HospitalParam> page = new PageParam<>(param);
        return success(hospitalService.page(page, page.getWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping()
    public ApiResult<List<Hospital>> list(HospitalParam param) {
        PageParam<Hospital, HospitalParam> page = new PageParam<>(param);
        return success(hospitalService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/{id}")
    public ApiResult<Hospital> get(@PathVariable("id") Integer id) {
        return success(hospitalService.getById(id));
    }

    @OperationLog
    @ApiOperation("添加")
    @PostMapping()
    public ApiResult<?> save(@RequestBody Hospital hospital) {
        User user = getLoginUser();
        hospital.setCreateUser(user.getUsername());
        hospital.setCreateTime(DateUtil.now());
        if (hospitalService.save(hospital)) {
            return success("添加成功");
        }
        return fail("添加失败");
    }

    @OperationLog
    @ApiOperation("修改")
    @PutMapping()
    public ApiResult<?> update(@RequestBody Hospital hospital) {
        if (hospitalService.updateById(hospital)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }

    @OperationLog
    @ApiOperation("删除")
    @DeleteMapping("/{id}")
    public ApiResult<?> remove(@PathVariable("id") Integer id) {
        if (hospitalService.removeById(id)) {
            return success("删除成功");
        }
        return fail("删除失败");
    }


}
