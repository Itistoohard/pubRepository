package com.eleadmin.common.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eleadmin.common.system.entity.Pet;

/**
 * 宠物Service
 */
public interface PetService extends IService<Pet> {

}
