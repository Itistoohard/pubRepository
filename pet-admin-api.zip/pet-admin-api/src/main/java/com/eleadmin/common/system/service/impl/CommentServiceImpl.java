package com.eleadmin.common.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Comment;
import com.eleadmin.common.system.mapper.CommentMapper;
import com.eleadmin.common.system.param.CommentParam;
import com.eleadmin.common.system.service.CommentService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 评论服务实现类
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {
    @Override
    public PageResult<Comment> pageRel(CommentParam param) {
        PageParam<Comment, CommentParam> page = new PageParam<>(param);
        page.setDefaultOrder("create_time desc");
        List<Comment> list = baseMapper.selectPageRel(page, param);
        return new PageResult<>(list, page.getTotal());
    }
    @Override
    public List<Comment> listRel(CommentParam param) {
        List<Comment> list = baseMapper.selectListRel(param);
        // 排序
        PageParam<Comment, CommentParam> page = new PageParam<>(param);
        page.setDefaultOrder("create_time desc");
        return page.sortRecords(list);
    }
}
