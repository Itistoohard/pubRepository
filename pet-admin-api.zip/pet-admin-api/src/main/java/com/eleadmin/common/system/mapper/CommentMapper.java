package com.eleadmin.common.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eleadmin.common.system.entity.Comment;
import com.eleadmin.common.system.param.CommentParam;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * 评论Mapper
 */
public interface CommentMapper extends BaseMapper<Comment> {

    /**
     * 分页查询
     *
     * @param page  分页对象
     * @param param 查询参数
     * @return List<Comment>
     */
    List<Comment> selectPageRel(@Param("page") IPage<Comment> page,
                                 @Param("param") CommentParam param);

    /**
     * 查询全部
     *
     * @param param 查询参数
     * @return List<Comment>
     */
    List<Comment> selectListRel(@Param("param") CommentParam param);

}
