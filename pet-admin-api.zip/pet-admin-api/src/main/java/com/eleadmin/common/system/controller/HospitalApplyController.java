package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Hospital;
import com.eleadmin.common.system.entity.HospitalApply;
import com.eleadmin.common.system.entity.User;
import com.eleadmin.common.system.param.HospitalApplyParam;
import com.eleadmin.common.system.service.HospitalApplyService;
import com.eleadmin.common.system.service.HospitalService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 医院控制器
 */
@Api(tags = "医院管理")
@RestController
@RequestMapping("/system/hospitalApply")
public class HospitalApplyController extends BaseController {
    @Resource
    private HospitalApplyService hospitalApplyService;
    @Resource
    private HospitalService hospitalService;


    @OperationLog
    @ApiOperation("分页查询")
    @GetMapping("/page")
    public ApiResult<PageResult<HospitalApply>> page(HospitalApplyParam param) {
        PageParam<HospitalApply, HospitalApplyParam> page = new PageParam<>(param);
        return success(hospitalApplyService.page(page, page.getWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping()
    public ApiResult<List<HospitalApply>> list(HospitalApplyParam param) {
        PageParam<HospitalApply, HospitalApplyParam> page = new PageParam<>(param);
        return success(hospitalApplyService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/{id}")
    public ApiResult<HospitalApply> get(@PathVariable("id") Integer id) {
        return success(hospitalApplyService.getById(id));
    }

    @OperationLog
    @ApiOperation("添加")
    @PostMapping()
    public ApiResult<?> save(@RequestBody HospitalApply hospitalApply) {
        User user = getLoginUser();
        Hospital hospital = hospitalService.getById(hospitalApply.getHospitalId());
        hospitalApply.setHospitalTitle(hospital.getTitle());
        hospitalApply.setCreateUser(user.getUsername());
        hospitalApply.setCreateTime(DateUtil.now());
        if (hospitalApplyService.save(hospitalApply)) {
            return success("添加成功");
        }
        return fail("添加失败");
    }

    @OperationLog
    @ApiOperation("修改")
    @PutMapping()
    public ApiResult<?> update(@RequestBody HospitalApply hospitalApply) {
        Hospital hospital = hospitalService.getById(hospitalApply.getHospitalId());
        hospitalApply.setHospitalTitle(hospital.getTitle());
        if (hospitalApplyService.updateById(hospitalApply)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }

    @OperationLog
    @ApiOperation("删除")
    @DeleteMapping("/{id}")
    public ApiResult<?> remove(@PathVariable("id") Integer id) {
        if (hospitalApplyService.removeById(id)) {
            return success("删除成功");
        }
        return fail("删除失败");
    }


}
