package com.eleadmin.common.system.controller;

import cn.hutool.core.date.DateUtil;
import com.eleadmin.common.core.annotation.OperationLog;
import com.eleadmin.common.core.web.ApiResult;
import com.eleadmin.common.core.web.BaseController;
import com.eleadmin.common.core.web.PageParam;
import com.eleadmin.common.core.web.PageResult;
import com.eleadmin.common.system.entity.Pet;
import com.eleadmin.common.system.entity.User;
import com.eleadmin.common.system.param.PetParam;
import com.eleadmin.common.system.service.PetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 宠物控制器
 */
@Api(tags = "宠物管理")
@RestController
@RequestMapping("/system/pet")
public class PetController extends BaseController {
    @Resource
    private PetService petService;


    @OperationLog
    @ApiOperation("分页查询")
    @GetMapping("/page")
    public ApiResult<PageResult<Pet>> page(PetParam param) {
        PageParam<Pet, PetParam> page = new PageParam<>(param);
        return success(petService.page(page, page.getWrapper()));
    }

    @OperationLog
    @ApiOperation("查询全部")
    @GetMapping()
    public ApiResult<List<Pet>> list(PetParam param) {
        PageParam<Pet, PetParam> page = new PageParam<>(param);
        return success(petService.list(page.getOrderWrapper()));
    }

    @OperationLog
    @ApiOperation("根据id查询")
    @GetMapping("/{id}")
    public ApiResult<Pet> get(@PathVariable("id") Integer id) {
        return success(petService.getById(id));
    }

    @OperationLog
    @ApiOperation("添加")
    @PostMapping()
    public ApiResult<?> save(@RequestBody Pet pet) {
        User user = getLoginUser();
        pet.setCreateUser(user.getUsername());
        pet.setCreateTime(DateUtil.now());
        if (petService.save(pet)) {
            return success("添加成功");
        }
        return fail("添加失败");
    }

    @OperationLog
    @ApiOperation("修改")
    @PutMapping()
    public ApiResult<?> update(@RequestBody Pet pet) {
        if (petService.updateById(pet)) {
            return success("修改成功");
        }
        return fail("修改失败");
    }

    @OperationLog
    @ApiOperation("删除")
    @DeleteMapping("/{id}")
    public ApiResult<?> remove(@PathVariable("id") Integer id) {
        if (petService.removeById(id)) {
            return success("删除成功");
        }
        return fail("删除失败");
    }


}
